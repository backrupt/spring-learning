package com.itwill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootTest
//@EnableJpaAuditing
public class SpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
