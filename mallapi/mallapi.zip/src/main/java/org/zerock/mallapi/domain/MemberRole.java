package org.zerock.mallapi.domain;

public enum MemberRole {

    USER, MANAGER,ADMIN;
}



