package com.itwill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
//@EnableJpaAuditing
public class SpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
