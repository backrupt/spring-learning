package com.itwill.jpa.entity;

import java.sql.Date;


public class Guest {
	
	private Long guestNo;
	private String guestName;
	private Date guestDate;
	private String guestEmail;
	private String guestHomepage;
	private String guestTitle;
	private String guestContent;
}
