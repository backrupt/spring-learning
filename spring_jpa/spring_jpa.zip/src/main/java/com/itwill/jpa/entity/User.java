package com.itwill.jpa.entity;

public class User {
	private String userId;
	private String password;
	private String name;
	private String email;
}
