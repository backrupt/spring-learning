package com.itwill.jpa.relation.entity;

public class Category{
	
	private Long categoryId;
	private String code;
	private String name;
	
	
	
}
