package com.itwill.jpa.relation.entity;

public class Product {
	private Long productId;
	private String name;
	private Integer price;
	private Integer stock;

	

	
	

}
