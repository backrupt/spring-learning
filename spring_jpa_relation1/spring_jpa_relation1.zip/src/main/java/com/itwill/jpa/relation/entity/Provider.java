package com.itwill.jpa.relation.entity;

public class Provider {
	private Long providerId;
	private String name;
}
