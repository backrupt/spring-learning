package com.itwill.jpa.relation.entity;

public class ProductDetail {
	private Long productDetailId;
	private String description;
	
	
}
