package com.itwill.jpa.relation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringJpaRelationApplicationTests {

	@Test
	void contextLoads() {
	}

}
