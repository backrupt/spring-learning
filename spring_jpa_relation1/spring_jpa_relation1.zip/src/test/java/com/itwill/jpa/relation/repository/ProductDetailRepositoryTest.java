package com.itwill.jpa.relation.repository;

import com.itwill.jpa.relation.SpringJpaRelationApplicationTests;

class ProductDetailRepositoryTest extends SpringJpaRelationApplicationTests{
	
	
	
	void productDetailWithProductSaveRead() {
		
									
		/*
		 연관관계설정(OWNER)
		 ProductDetail-->Product
		*/
	
		
		System.out.println("--------read-----------");
		
		
	}
	
}
