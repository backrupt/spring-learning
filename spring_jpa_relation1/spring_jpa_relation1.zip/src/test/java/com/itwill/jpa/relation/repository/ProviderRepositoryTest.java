package com.itwill.jpa.relation.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.itwill.jpa.relation.SpringJpaRelationApplicationTests;

class ProviderRepositoryTest extends SpringJpaRelationApplicationTests {
	

	
	@Test
	void providerWithProductsSaveAndRead() {
		
		/*
		 * 연관설정 Provider-->Product
		 */
		
		
		
		
		System.out.println("----------read----------");
		
		
	}
}
