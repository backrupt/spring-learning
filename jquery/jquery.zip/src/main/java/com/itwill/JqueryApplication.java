package com.itwill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JqueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(JqueryApplication.class, args);
	}

}
