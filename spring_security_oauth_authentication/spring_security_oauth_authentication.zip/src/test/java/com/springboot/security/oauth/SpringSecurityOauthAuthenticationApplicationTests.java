package com.springboot.security.oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityOauthAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
