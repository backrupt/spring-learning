package com.itwill.ajax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebApplicationRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
