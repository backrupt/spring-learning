package com.itwill.user.exception;

public class PasswordMismatchException extends Exception {
	public PasswordMismatchException(String msg) {
		super(msg);
	}
}
